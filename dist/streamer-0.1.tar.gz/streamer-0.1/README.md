# streamer
A convenient API for accessing OpenCV's VideoCapture
