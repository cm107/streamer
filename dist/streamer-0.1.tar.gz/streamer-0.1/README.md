# streamer
A convenient API for streaming and recording with OpenCV

## Installation
```console
pip install git+https://github.com/cm107/streamer#egg=streamer
```