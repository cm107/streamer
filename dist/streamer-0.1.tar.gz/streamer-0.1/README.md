# streamer
A convenient API for streaming and recording with OpenCV

## Installation
```console
pip install https://github.com/cm107/streamer/archive/v0.1.zip
```