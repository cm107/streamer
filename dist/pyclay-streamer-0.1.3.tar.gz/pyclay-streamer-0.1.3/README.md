# streamer
A convenient API for streaming and recording with OpenCV

## Installation
### Install From Github
```console
pip install https://github.com/cm107/streamer/archive/master.zip
```

### Install From Pypi
```console
pip install pyclay-streamer
```